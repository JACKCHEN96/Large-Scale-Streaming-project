from pyspark import SparkConf, SparkContext
#
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
import csv
#
spark=SparkSession.builder.appName('myApp').getOrCreate()
#
# sc= SparkContext("local","App")
sc=SparkContext.getOrCreate(SparkConf().setMaster("local[*]"))
lines = sc.textFile("epa-http.txt")

ip_bytes=lines.map(lambda x: (x.split(" ")[0], x.split(" ")[-1]))

# Drop all non-IP addresses
ip_bytes=ip_bytes.filter((lambda x: x[0].replace(".","").isdigit()))

ip_bytes_value=ip_bytes.mapValues(lambda x: int(x) if x.isdigit() else 0)

total=ip_bytes_value.reduceByKey(lambda a, b: a + b)

total=total.sortByKey()

print(ip_bytes.take(20))
print(ip_bytes_value.take(20))
print(total.collect())

# with open('hw1-part1.csv',"w") as csv_file:
#     wr = csv.writer(csv_file, quoting=csv.QUOTE_ALL)
#     wr.writerow(total.collect())


df=spark.createDataFrame(total,schema=['IP','Bytes']).repartition(1)
file=r"hw1-part1.csv"
df.write.csv(path=file,header=True,sep=",",mode='overwrite')




