from pyspark import SparkConf, SparkContext
#
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
import csv
#
spark=SparkSession.builder.appName('myApp').getOrCreate()
#
# sc= SparkContext("local","App")
sc=SparkContext.getOrCreate(SparkConf().setMaster("local[*]"))
lines = sc.textFile("epa-http.txt")

ip_time_bytes_np=lines.map(lambda x: (x.split(" ")[0],x.split(" ")[1], x.split(" ")[-1]))

# Drop all non-IP addresses
ip_time_bytes_np=ip_time_bytes_np.filter((lambda x: x[0].replace(".","").isdigit()))

ip_time_bytes=ip_time_bytes_np.filter(lambda x: x[-1].isdigit())
print("Ip_time_bytes for all")
print(ip_time_bytes.take(70))
print("\n")
# day 29:
# we found that all the hour is 23
dayone_ip_time_bytes=ip_time_bytes.filter(lambda  x: x[1].split(":")[0]=='[29')
dayone_ip_bytes=dayone_ip_time_bytes.map(lambda  x: (x[0],x[2]))
dayone_total=dayone_ip_bytes.reduceByKey(lambda x,y:int(x)+int(y))

print("Day 29")
print(dayone_ip_bytes.take(70))
print("Day 29, at 23, the total number of bytes served by each unique ip address is:")
print(dayone_total.take(50))
print("\n")

# day 30:
print("Day 30")
daytwo_ip_time_bytes=ip_time_bytes.filter(lambda  x: x[1].split(":")[0]=='[30')
print(daytwo_ip_time_bytes.take(20))
print("\n")

for i in range(24):
    print("%d hour"%i)
    daytwo_temp_ip_time_bytes=daytwo_ip_time_bytes.filter(lambda x: int(x[1].split(":")[1])==i)
    daytwo_temp_ip_bytes=daytwo_temp_ip_time_bytes.map(lambda x: (x[0],x[2]))
    print(daytwo_temp_ip_bytes.take(20))
    print("\n")

# 30:00:00:00 to 30:00:59:59
daytwo_temp_ip_time_bytes=daytwo_ip_time_bytes.filter(lambda x: int(x[1].split(":")[1])==0)
daytwo_temp_ip_bytes=daytwo_temp_ip_time_bytes.map(lambda x: (x[0],int(x[2])))
daytwo_temp_ip_bytes=daytwo_temp_ip_bytes.reduceByKey(lambda a, b: a + b)

daytwo_temp_ip_bytes=daytwo_temp_ip_bytes.sortByKey()
print(daytwo_temp_ip_bytes.take(20))
print("\n")

df=spark.createDataFrame(daytwo_temp_ip_bytes,schema=['IP','Bytes']).repartition(1)
file=r"hw1-part3.csv"
df.write.csv(path=file,header=True,sep=",",mode='overwrite')


# print(ip_hour_bytes.collect())