from pyspark import SparkConf, SparkContext
#
from pyspark.sql.functions import *
from pyspark.sql import SparkSession

spark=SparkSession.builder.appName('myApp').getOrCreate()
#
# sc= SparkContext("local","App")
sc=SparkContext.getOrCreate(SparkConf().setMaster("local[*]"))
lines = sc.textFile("epa-http.txt")

ip_bytes=lines.map(lambda x: (x.split(" ")[0], x.split(" ")[-1]))

# Drop all non-IP addresses
ip_bytes=ip_bytes.filter((lambda x: x[0].replace(".","").isdigit()))

ip_bytes_value=ip_bytes.mapValues(lambda x: int(x) if x.isdigit() else 0)

total=ip_bytes_value.reduceByKey(lambda a, b: a + b)

# print(ip_bytes_value.take(20))
# print(total.collect())

# toplist = ip_bytes_value.sortBy(lambda x: -x[1])
toplist = total.sortBy(lambda x: -x[1])

# k = int(sys.argv[1])
k1=10
top_10=toplist.take(k1)

k2=100
top_100=toplist.take(k2)

print(top_10)
print(top_100)

df=spark.createDataFrame(top_10,schema=['IP','Bytes']).repartition(1)
file=r"hw1-part2_top10.csv"
df.write.csv(path=file,header=True,sep=",",mode='overwrite')

df=spark.createDataFrame(top_100,schema=['IP','Bytes']).repartition(1)
file=r"hw1-part2_top100.csv"
df.write.csv(path=file,header=True,sep=",",mode='overwrite')
