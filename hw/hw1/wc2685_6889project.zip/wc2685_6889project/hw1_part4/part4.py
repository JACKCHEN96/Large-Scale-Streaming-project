from pyspark import SparkConf, SparkContext
#
from pyspark.sql.functions import *
from pyspark.sql import SparkSession

#
spark=SparkSession.builder.appName('myApp').getOrCreate()
#
# sc= SparkContext("local","App")
sc=SparkContext.getOrCreate(SparkConf().setMaster("local[*]"))
lines = sc.textFile("epa-http.txt")
lines=lines.filter(lambda x: len(x.split(" ")[0].split("."))==4)

ip_bytes_np=lines.map(lambda x: (x.split(" ")[0].split(".")[0], x.split(" ")[0].split(".")[1], x.split(" ")[0].split(".")[2], x.split(" ")[-1]))
ip_bytes_sperate=ip_bytes_np.filter(lambda x: x[-1].isdigit())
# print(ip_bytes_sperate.take(20))

ip_bytes_d = ip_bytes_sperate.filter(lambda x: x[0].isdigit() and x[1].isdigit() and x[2].isdigit())
# print(ip_bytes_d.take(20))
ip_bytes_d_u = ip_bytes_d.map(lambda x: (str(x[0]) + '.' + str(x[1]) + '.' + str(x[2]), x[-1]))
# print(ip_bytes_d_u.take(20))

ip_bytes_d_sum = ip_bytes_d_u.reduceByKey(lambda x, y: int(x)+int(y))
ip_bytes_d_sum=ip_bytes_d_sum.sortByKey();
print(ip_bytes_d_sum.collect())

df=spark.createDataFrame(ip_bytes_d_sum,schema=['Subnet','Bytes']).repartition(1)
file=r"hw1-part4.csv"
df.write.csv(path=file,header=True,sep=",",mode='overwrite')

#
# data2 = data.filter(lambda x: x[0].isdigit() == False or x[1].isdigit() == False or x[2].isdigit() == False)
# data2 = data2.map(lambda x: (str(x[0]) + '.' + str(x[1]), x[3]))
# data2 = data2.reduceByKey(lambda x, y: int(x) + int(y))
# print(data2.take(5))