# hw1_part1
import findspark
findspark.init()
from pyspark import SparkConf, SparkContext
import re

def function():

    sc = SparkContext()
    # read in data 
    input = sc.textFile("epa-http.txt") 
    # only include addresses that have numeric values and remove '-' line in Bytes
    lines = input.filter(lambda x:re.match(r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$", x.split(" ")[0])).filter(lambda x:x[-1] !='-')
    # select the first column and last column : IP address, Bytes with split function 
    pairlines = lines.map(lambda x: (x.split(" ")[0], int(x.split(" ")[-1]))) 
    # apply on multiple partitions and returns final RDD with total counts paired with keys
    res = pairlines.reduceByKey(lambda x,y: x+y) 
    # sort by IP in string ascending order
    res = res.sortBy(lambda x:x[0])
    # write into csv file
    res = res.collect()

    f = open('part1.csv','w+')
    for i in res:
        f.write(str(i)+'\n')
    f.close()

if __name__ =='__main__':
    function()


