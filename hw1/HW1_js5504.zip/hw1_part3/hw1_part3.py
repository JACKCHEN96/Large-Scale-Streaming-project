# hw1_part3
import findspark
findspark.init()
from pyspark import SparkConf, SparkContext
import re 

def function():
    # read in data
    sc = SparkContext()
    lines = sc.textFile("epa-http.txt")
    # only include addresses that have numeric values 
    lines = lines.filter(lambda x:re.match(r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$", x.split(" ")[0]))
    # select the first column, second column and last column : IP address, Time, Bytes with split function 
    rdd = lines.map(lambda x: (x.split(" ")[0], x.split(" ")[1], x.split(" ")[-1]))
    # select results for interval 30:00:00:00 to 30:00:59:59 and remove '-' line in Bytes
    rdd = rdd.filter(lambda x:x[1].split(':')[1]=='00').filter(lambda x: x[2] != "-")
    # select the first column and last column : IP address and Bytes 
    rdd = rdd.map(lambda x: (x[0], int(x[-1])))
    # apply on multiple partitions and returns final RDD with total counts paired with keys
    rdd = rdd.reduceByKey(lambda x,y:x+y)
    # sort by IP in string ascending order 
    rdd = rdd.sortBy(lambda x:x[0])
    # write into csv file
    res = rdd.collect()

    f = open('part3.csv','w+')
    for i in res:
        f.write(str(i)+'\n')
    f.close() 

if __name__ =='__main__':
    function()
