# hw1_part4
import findspark
findspark.init()
from pyspark import SparkConf, SparkContext

def function():
    
    sc = SparkContext()
    # read in data and select the first 3 bytes in IP addresses and the Bytes 
    input = sc.textFile("epa-http.txt").map(lambda x: (x.replace('.',' ').split(' ')[0], x.replace('.',' ').split(' ')[1], x.replace('.',' ').split(' ')[2], x.split(" ")[-1]))
    # remove the '-' line
    input = input.filter(lambda x: x[-1] !='-')
    # select IP addresses that have only numeric values 
    input = input.filter(lambda x: x[0].isdigit() == True and x[1].isdigit() == True and x[2].isdigit() == True)
    # aggregate all IP with the same first 3 bytes 
    input = input.map(lambda x: (str(x[0]) + '.' + str(x[1]) + '.' + str(x[2]), x[-1]))
    res = input.reduceByKey(lambda x,y: int(x) + int(y))
    # sort by IP in string ascending order
    res = res.sortBy(lambda x:x[0]) 
    # write in to csv file
    res = res.collect()

    f = open('part4.csv','w+')
    for i in res:
        f.write(str(i)+'\n')
    f.close()

if __name__ =='__main__':
    function()

