# hw1_part2
import findspark
findspark.init()
from pyspark import SparkConf, SparkContext
import re

def function():

    sc = SparkContext()
    # read in data 
    input = sc.textFile("epa-http.txt")
    # only include addresses that have numeric values and remove '-' line in Bytes
    lines = input.filter(lambda x:re.match(r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$", x.split(" ")[0])).filter(lambda x:x[-1] !='-')
    # select the first column and last column : IP address, Bytes with split function
    pairlines = lines.map(lambda x:(x.split(" ")[0],int(x.split(" ")[-1])))
    # apply on multiple partitions and returns final RDD with total counts paired with keys
    res = pairlines.reduceByKey(lambda x,y:x+y) 
    # sort by Bytes in descending order
    res_sort = res.sortBy(lambda x:x[-1], ascending = False)  
    # write into csv file for the top 100 IPs
    res = res_sort.collect()

    f = open('part2_10.csv','w+')
    count = 0
    k = 10
    for i in res:
        f.write(str(i)+'\n')
        count += 1
        print(count)
        if count > k-1:
        	f.close()

if __name__ =='__main__':
    function()
